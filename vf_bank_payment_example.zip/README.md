
# VF Bank Payment Example

Este projeto demonstra um fluxo de pagamento com cartão usando **Stripe** e faz o payout automático para a conta bancária (**Banco 380 · Ag 0001 · Conta 55084078-8**) configurada como conta de destino no próprio dashboard da Stripe.

> **Importante**  
> Para que os valores sejam transferidos para essa conta, você precisa:
> 1. Criar/entrar na sua conta Stripe.<br/>
> 2. Registrar a conta bancária como conta de **"Payout"** (Banco 380, Agência 0001, Conta 55084078-8).<br/>
> 3. Habilitar pagamentos em BRL e payouts para bancos no Brasil.  
> O código abaixo **não** envia dados bancários; ele apenas cria o pagamento. O repasse para o banco é feito automaticamente pela Stripe.

## Estrutura

```
payment-app/
│
├── public/
│   └── index.html         # Front‑end (Stripe Elements + validação Luhn)
│
├── server.js              # Back‑end Node.js (Express + Stripe)
├── package.json
├── .env.example
└── README.md
```

## Como rodar localmente

```bash
git clone https://github.com/seu-usuario/vf-bank-pagamentos.git
cd vf-bank-pagamentos

# Crie o arquivo .env baseado em .env.example
cp .env.example .env
# edite .env e coloque sua STRIPE_SECRET_KEY

npm install
npm start      # inicia na porta 4242
```

Abra [http://localhost:4242](http://localhost:4242) e teste com os cartões de teste da Stripe.

## Segurança

- Os dados do cartão **nunca** tocam seu servidor; o Stripe Elements os envia direto aos servidores Stripe.
- O **.env** e as chaves secretas **não** devem ser commitados no Git.
- Nunca coloque código secreto no front‑end.

## Próximos Passos

- Implementar autenticação de usuário.
- Salvar registros de pagamentos em um banco de dados.
- Configurar HTTPS em produção.
